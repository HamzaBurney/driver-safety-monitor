# SeatBelt > 2024-12-15 12:36pm
https://universe.roboflow.com/seatbelts-and-carplates/seatbelt-hd0r6

Provided by a Roboflow user
License: undefined

